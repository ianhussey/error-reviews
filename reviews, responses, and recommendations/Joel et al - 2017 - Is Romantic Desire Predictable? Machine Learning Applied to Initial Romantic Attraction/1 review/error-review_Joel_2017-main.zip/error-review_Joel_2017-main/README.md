This repository contains supplementary online materials for the [ERROR review](https://error.reviews/reviews/joel-et-al-2017/) of:

Joel, S., Eastwick, P. W., & Finkel, E. J. (2017). Is Romantic Desire Predictable? Machine Learning Applied to Initial Romantic Attraction. *Psychological Science*, 28(10), 1478-1489. <https://doi.org/10.1177/0956797617714580>
